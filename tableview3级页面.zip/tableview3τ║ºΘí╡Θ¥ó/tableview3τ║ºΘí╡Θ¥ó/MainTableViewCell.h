//
//  MainTableViewCell.h
//  tableview3级页面
//
//  Created by Xuan on 16/6/14.
//  Copyright © 2016年 Liuqi. All rights reserved.
//
typedef void (^Callback)(id obj);
#import <UIKit/UIKit.h>

@interface MainTableViewCell : UITableViewCell<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, assign) NSInteger mainsection;
@property (nonatomic, strong) NSArray *detailsarr;
@property (nonatomic, strong) NSMutableArray *sections;
@property (nonatomic, assign) NSInteger cellsection;
@property (nonatomic, copy) Callback mycallback;
-(void)didselectcell:(Callback )callback;
@end
