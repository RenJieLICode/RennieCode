//
//  AppDelegate.h
//  tableview3级页面
//
//  Created by Xuan on 16/6/14.
//  Copyright © 2016年 Liuqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

