//
//  TableViewMainHeaderView.h
//  tableview3级页面
//
//  Created by Xuan on 16/6/14.
//  Copyright © 2016年 Liuqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewMainHeaderView : UITableViewHeaderFooterView

@property (strong, nonatomic) IBOutlet UIButton *btn;
@property (strong, nonatomic) IBOutlet UILabel *title;

@end
