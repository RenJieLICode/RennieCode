//
//  ViewController.h
//  tableview3级页面
//
//  Created by Xuan on 16/6/14.
//  Copyright © 2016年 Liuqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
-(void)refreshCellWithArray:(NSArray *)arr;

@end

