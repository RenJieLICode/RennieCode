//
//  ViewController.m
//  tableview3级页面
//
//  Created by Xuan on 16/6/14.
//  Copyright © 2016年 Liuqi. All rights reserved.
//

#import "ViewController.h"
#import "TableViewMainHeaderView.h"
#import "MainTableViewCell.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tableView;
//数据源
@property (nonatomic, strong) NSArray *detailsarr;
//存本页面打开的分组
@property (nonatomic, strong) NSMutableArray *sections;
//存cell里打开的分组
@property (nonatomic, strong) NSMutableArray *opensections;
//返回的cell高度
@property (nonatomic, strong) NSMutableArray *cellheights;
@end

@implementation ViewController{
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *path = [[NSBundle mainBundle]pathForResource:@"options" ofType:@"plist"];
    self.detailsarr = [[NSArray array]initWithContentsOfFile:path];
    self.sections = [NSMutableArray array];
    self.opensections = [NSMutableArray array];
    self.cellheights = [NSMutableArray array];
    //初始化cell高度；
    for (int i=0; i<self.detailsarr.count; i++) {
        CGFloat cheight = 0;
        [self.cellheights addObject:@(cheight)];
    }
}
//cell分组点击事件回调；
-(void)refreshCellWithArray:(NSArray *)arr{
    
    NSNumber *n1 = arr[0];
    NSInteger section = n1.integerValue;
    NSNumber *n2 = arr[1];
    NSInteger index = n2.integerValue;
    NSArray *groupArr;
    if (self.detailsarr[section][@"groupArr"][index][@"groupValues"]) {
    groupArr =self.detailsarr[section][@"groupArr"][index][@"groupValues"];
    }
    NSNumber *n3 =self.cellheights[section];
    CGFloat cheight = n3.floatValue;
    
    //重置数据源；
    if (![self.opensections containsObject:n2]) {
        [self.opensections addObject:n2];
        cheight += 30*groupArr.count;
        
    }else{
        [self.opensections removeObject:n2];
        cheight -= 30*groupArr.count;
    }
    
    [self.cellheights setObject:@(cheight) atIndexedSubscript:section];
    //刷新所点击的主分组；
    [self.tableView reloadSections:[[NSIndexSet alloc]initWithIndex:section] withRowAnimation:UITableViewRowAnimationFade];
}
-(void)btnAction:(UIButton *)btn{
    //首页分组点击事件
    [self.opensections removeAllObjects];
    NSNumber *number = self.cellheights[btn.tag];
    CGFloat cellheight = number.floatValue;
    cellheight = 0;
    [self.cellheights setObject:@(cellheight) atIndexedSubscript:btn.tag];
    
    if ([self.sections containsObject:@(btn.tag)]) {
        [self.sections removeObject:@(btn.tag)];
    }else{
        [self.sections addObject:@(btn.tag)];
    }
    [self.tableView reloadSections:[[NSIndexSet alloc]initWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
    
}
//分组个数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.detailsarr.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if ([self.sections containsObject:@(section)]) {
        return 1;
    }else{
        return 0;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    TableViewMainHeaderView *view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"TableViewMainHeaderView"];
    if (!view) {
        view = [[NSBundle mainBundle]loadNibNamed:@"TableViewMainHeaderView" owner:nil options:nil][0];
    }
    NSString *groupNames = self.detailsarr[section][@"groupNames"];
    view.title.text = groupNames;
    view.btn.tag = section;
    [view.btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell"];
    if (!cell) {
        cell =[[NSBundle mainBundle]loadNibNamed:@"MainTableViewCell" owner:nil options:nil][0];
    }
    cell.detailsarr = self.detailsarr[indexPath.section][@"groupArr"];
    cell.cellsection = indexPath.section;
    cell.sections = self.opensections;
    cell.mainsection = indexPath.section;
    __weak ViewController *weakself = self;
    [cell didselectcell:^(id obj) {
        [weakself refreshCellWithArray:obj];
    }];
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSArray *groupArr =self.detailsarr[indexPath.section][@"groupArr"];
    NSNumber *numebr = self.cellheights[indexPath.section];
    CGFloat cellheight = numebr.floatValue;
    CGFloat height =50*groupArr.count +cellheight;
    return height;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 50;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
