//
//  MainTableViewCell.m
//  tableview3级页面
//
//  Created by Xuan on 16/6/14.
//  Copyright © 2016年 Liuqi. All rights reserved.
//

#import "MainTableViewCell.h"
#import "TableViewMainHeaderView.h"
@implementation MainTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.sections = [NSMutableArray array];
}
-(void)btnAction:(UIButton *)btn{
    //第一个值是所在的主分组，第二个所点击的分组
    self.mycallback(@[@(self.cellsection),@(btn.tag)]);
    
}
//block
-(void)didselectcell:(Callback)callback{
    if (self.mycallback!=callback) {
        self.mycallback = [callback copy];
    }
}
//分组个数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.detailsarr.count;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if ([self.sections containsObject:@(section)]) {
        NSArray *groupValues = self.detailsarr[section][@"groupValues"];
        return groupValues.count;
    }else{
        return 0;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    TableViewMainHeaderView *view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"TableViewMainHeaderView"];
    if (!view) {
        view = [[NSBundle mainBundle]loadNibNamed:@"TableViewMainHeaderView" owner:nil options:nil][0];
    }
    NSString *groupNames = [NSString stringWithFormat:@"     %@",self.detailsarr[section][@"groupNames"]];
    view.title.text = groupNames;
    view.btn.tag = section;
    [view.btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
        
        cell.textLabel.text = [NSString stringWithFormat:@"       %@",self.detailsarr[indexPath.section][@"groupValues"][indexPath.row]];
    
   

    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 50;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
